# Photo protocol — how to take pictures the model can trust

## Your current setup, reviewed

A big gray card with the glass centered on it: **this is genuinely good**, and
better than most published student projects. The gray surrounds the sample, so
the reference and the sample share exactly the same illumination. Two
corrections, though:

**The target at the center of your card is now useless — and slightly
harmful.** The glass sits on top of it, so the software can never sample it,
and if any of the target's black/white rings peek out around the glass base
they can contaminate the sample patch. The gray reference must come from a
*clean gray region beside the glass*. The app expects it to the **left of the
sample, at mid-height** (the dashed box in the viewfinder) — so orient your
card with an unmarked gray area there, and check before every session that the
dashed box lands on pure gray: no target rings, no shadow, no edge of the
card.

**Watch the glass's own shadow.** A glass on a card casts a shadow, usually
opposite the light source. If that shadow falls where the gray is sampled,
your white balance is computed from "gray + shadow" and every reading shifts.
Fix: light from two sides (two lamps, or a lamp plus a white wall/paper
reflector), or simply rotate the card so the sampled gray sits on the lit
side.

## The full protocol

1. **Solutions.** For calibration, prepare each reference independently and
   verify its pH with a calibrated meter or a fresh buffer sachet — the model
   can never be more accurate than the labels you feed it. Use the same
   indicator, same number of drops, same solution volume every time: indicator
   concentration changes color intensity, and the model will happily learn
   "3 drops vs 5 drops" instead of pH if you let it vary.

2. **Vessel.** Same glass (or same type) every time, filled to the same
   height. Colored liquid seen through more liquid looks darker — path length
   is part of your measurement whether you like it or not, so standardize it.
   A plain cylindrical glass beats a faceted one (facets create glare stripes).

3. **Framing.** Glass centered, card filling most of the frame, camera
   looking slightly down at a consistent angle (mark the phone position with
   tape on a stand if you can — a stack of books with a tape mark works).
   The sample circle in the app should see only liquid: not the rim of the
   glass, not the card behind it, not the meniscus.

4. **Lighting.** Diffuse and even beats bright. Avoid direct sunlight and
   bare bulbs aimed at the glass — both create specular highlights on the
   glass wall, and a big glare spot inside the sample circle will poison the
   reading despite the software's median filtering. Overcast daylight from a
   window, or a lamp bounced off a white surface, is ideal.

5. **Camera settings.** If your camera app allows it, lock exposure and
   white balance (tap-and-hold on most Androids gives AE/AF lock). Auto white
   balance is your enemy: it "helpfully" neutralizes the very color you're
   measuring. The gray card correction cleans up most of what remains, but
   locked settings plus the card is the strongest combination. Never use
   flash — it's a guaranteed glare spot.

6. **Deliberate variation (for calibration and dataset photos).** Uniformity
   within one photo, diversity across photos. Capture each reference under at
   least two lighting setups and, if possible, two phones. A model trained on
   one lamp learns that lamp; a model trained on varied light learns the
   chemistry.

7. **Hygiene between samples.** Rinse the glass with distilled water and a
   final rinse of the next sample. Carry-over from a pH 2 solution into a
   pH 7 sample shifts it measurably — your indicator will show you the
   contamination before you realize what happened.

## Quick pre-shot checklist

Gray patch region clean and shadow-free → no glare spot inside the sample
circle → liquid fills the sample circle completely → same fill height and
drop count as always → exposure/white balance locked → shoot.

## One experiment worth doing (and writing up)

Photograph the same pH 7 sample ten times while deliberately breaking one rule
at a time — flash on, shadow over the gray patch, half fill height, direct
sun — and record what the app reads. You'll get a table of "error caused by
each mistake", which is exactly the kind of systematic-uncertainty analysis
that turns a cool app into a defensible instrument, and it writes itself into
any competition report or application essay.
