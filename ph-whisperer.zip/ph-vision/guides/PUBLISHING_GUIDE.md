# Publishing pH Whisperer online

The whole app is one file, `index.html`, with no server behind it. That means
you can host it anywhere that serves static files — and the best free option
also solves your biggest technical problem: **phone browsers only allow camera
access over HTTPS**, and GitHub Pages gives you HTTPS automatically. Once
published, the live camera just works on any phone.

## Option A — GitHub Pages (recommended, permanent, free)

1. Create a free account at github.com if you don't have one (you'll want one
   for university applications anyway — a visible project portfolio matters).
2. Click the "+" in the top-right corner → **New repository**. Name it
   `PH-Whisperer`, set it to **Public**, and create it.
3. On the repository page, click **Add file → Upload files**, drag in
   `index.html`, and press **Commit changes**.
4. Go to **Settings → Pages** (left sidebar). Under "Build and deployment",
   set Source to **Deploy from a branch**, choose branch `main` and folder
   `/ (root)`, and save.
5. Wait one or two minutes, refresh the page, and GitHub shows your live URL:

   `https://<your-username>.github.io/PH-Whisperer/`

6. Open that address on your phone — the camera permission prompt should
   appear immediately, because the connection is HTTPS.

To update the app later, upload a new `index.html` over the old one (same
Upload files button). Changes go live within a minute or two.

## Option B — Netlify Drop (fastest, good for a demo today)

Go to `app.netlify.com/drop`, drag the folder containing `index.html` onto the
page, and you get an HTTPS link in about ten seconds, no account required at
first. Links from anonymous drops expire, so claim the site with a free
account if you want to keep it.

## Nice touches once you're live

**QR code.** The app now generates its own: Calibrate → Get code → Show QR →
Save QR image. That QR opens the app *with the calibration already loaded* —
print it on your gray card or lab handout and a teacher is measuring within
seconds of scanning. (For a plain QR that just opens the app with no
calibration, any free QR generator pointed at your URL works too.)

**Custom domain (optional).** A domain like `phvision.app` costs a few
euros/year; both GitHub Pages and Netlify let you attach it in settings and
handle the HTTPS certificate for you. Not necessary, but it looks serious on
a poster or an application.

**Install to home screen.** On Android Chrome, Menu → "Add to Home screen"
turns the page into an app icon that opens full-screen. Mention this in your
instructions — for users it is indistinguishable from a native app, with no
Play Store involved.

**Sharing calibrations.** One person calibrates carefully, presses **Get
code**, and shares the code (paste it in any chat) or presses **Show QR**.
The code *contains* the whole calibration — there is no server behind it, so
codes never expire and work offline. Scanning the QR opens the app with the
calibration pre-loaded: the gray card becomes the instrument, the reference,
and the installer in one printed object.

## What to check after publishing

Open the live URL on at least two different phones and confirm: the camera
starts, the Upload photo fallback works, a calibration exports and re-imports
cleanly, and the demo-calibration warning appears until you add real points.
That five-minute test is your release checklist.
