# pH Whisperer — marketing & positioning guide

## The one-sentence pitch

**"Turn any phone into a pH reader for the price of indicator solution."**

Everything else you say should support that sentence. A digital pH meter
costs €50–500 and needs calibration buffers, storage solution, and electrode
replacement. Your product needs a phone (which the user already owns), a few
milliliters of indicator, and a printed gray card.

## Be honest about what it is — this is your strength, not a weakness

pH Whisperer is a *screening* tool, roughly ±0.3–0.5 pH depending on
calibration quality. It is not a certified instrument and it does not
certify water as safe to drink. Say this loudly and early. Counterintuitively,
this honesty is a selling point: teachers, NGOs, and reviewers are allergic to
overselling, and a tool that states its own uncertainty (yours literally
displays a ± value and refuses to guess when the color is unfamiliar) reads as
serious science. Your competitors in the "cheap sensing" space almost never do
this.

## Three audiences, three messages

**1. School chemistry labs (your beachhead — start here).**
The problem: a class of 30 students and two pH meters, or none. The message:
every student's phone becomes an instrument; the whole class measures
simultaneously; the calibration process *is itself a lesson* in color science,
measurement error, and machine reasoning. Package it as a ready-made lab
protocol (aims, materials, procedure, worksheet questions) — teachers adopt
protocols, not apps. You have a direct channel: ViaSTEM's network, your own
teachers at Vianu, and Romania's chemistry olympiad community. A pilot in two
or three Bucharest schools with a short written report ("30 students, 90
measurements, mean absolute deviation vs. a reference meter of X") is worth
more than any advertisement.

**2. Low-resource field testing (NGOs, rural clinics, community monitoring).**
The message: no equipment to break, lose, or maintain; works offline after
first load; one expert calibrates, everyone imports the file. Be careful and
humble here — water safety is a domain with real stakes, so position as
"first-line screening that tells you where to send a real test kit", never as
a replacement for lab analysis. If you pursue this seriously, look at
organizations already doing citizen water monitoring and offer the tool for
free; credibility in this space is earned, not marketed.

**3. Home users (aquariums, hydroponics, gardening, soil, cosmetics-making).**
These hobbyists already buy indicator drops and squint at color charts by eye.
The message: stop guessing between "6.8 and 7.2 on the chart" — the app reads
the color objectively and remembers your calibration. This audience is reached
through demonstration videos: a 30-second clip of red cabbage indicator +
three household liquids + the app reading them live is inherently shareable.

## Channels, in order of effort-to-impact

Start with what you control: a demo at ViaSTEM events and school science
fairs, where the QR-code-on-the-gray-card trick gets the app onto strangers'
phones in seconds. Then short vertical videos (the color changes are visually
gorgeous — the product demos itself). Then a simple landing page: the pitch
sentence, a 30-second video, the live app link, and the honest accuracy
statement. Competitions are marketing too: this project fits science fairs
and app contests, and every award is a line of credibility.

## Things that will hurt you if ignored

Never imply the app certifies drinking water safety — pH is one parameter
among many (turbidity, nitrates, bacteria), and "your water is fine" is a
claim you cannot back. Keep the WHO-guideline wording exactly as the app
states it: within/outside the *pH guideline*, nothing more. Don't promise
accuracy you haven't measured; publish your validation numbers instead.
And keep the app free for schools whatever else you do — goodwill in your
first audience is the asset everything else builds on.

## A name-level detail

"pH Whisperer" describes the mechanism. If you ever want a name that describes
the *benefit*, keep a shortlist (AquaCheck-style names are crowded; something
Romanian-rooted could be distinctive internationally). Don't rebrand now —
just register the .app or .io domain of whatever name you settle on before
you print posters.
